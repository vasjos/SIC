package com.sic.oti.tramites.model;

public class DescripcionTramites {

}
