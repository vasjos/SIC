package com.sic.oti.tramites.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name= "documentos" , schema="Tramites")
public class Documentos {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int tipodocumento;
	private String descripcion;
	
	public Documentos()
	{
	}
	public int getTipodocumento() {
		return tipodocumento;
	}
	public void setTipodocumento(int tipodocumento) {
		this.tipodocumento = tipodocumento;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}
