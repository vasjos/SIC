/**
 * 
 */
/**
 * @author Jose Vasquez
 *
 */
package com.sic.oti.tramites.model;