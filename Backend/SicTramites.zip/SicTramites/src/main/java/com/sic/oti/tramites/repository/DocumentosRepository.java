/**
 * 
 */
package com.sic.oti.tramites.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sic.oti.tramites.model.Documentos;

/**
 * @author Jose Vasquez
 *
 */
public interface DocumentosRepository extends JpaRepository<Documentos, Long>{

}
