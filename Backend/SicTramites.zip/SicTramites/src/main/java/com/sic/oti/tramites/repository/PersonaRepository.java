/**
 * 
 */
package com.sic.oti.tramites.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sic.oti.tramites.model.Persona;

/**
 * @author Jose Vasquez
 *
 */
public interface PersonaRepository extends JpaRepository<Persona, Long>{

}
