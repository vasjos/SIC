/**
 * 
 */
/**
 * @author Jose Vasquez
 *
 */
package com.sic.oti.tramites.repository;