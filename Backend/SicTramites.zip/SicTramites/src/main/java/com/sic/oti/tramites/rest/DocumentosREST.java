/**
 * 
 */
package com.sic.oti.tramites.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sic.oti.tramites.model.Documentos;
import com.sic.oti.tramites.services.DocumentosService;

/**
 * @author Jose Vasquez
 *
 */
@RestController
@RequestMapping("/documentos/")
public class DocumentosREST {

	@Autowired
	private DocumentosService documentosService;
	
	@GetMapping
	private ResponseEntity<List<Documentos>> getAllDocumentos (){
		return ResponseEntity.ok(documentosService.findAll());
	}
}
