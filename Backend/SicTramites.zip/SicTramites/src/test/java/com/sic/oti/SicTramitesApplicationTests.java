package com.sic.oti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SicTramitesApplicationTests {

	@Test
	void contextLoads() {
	}

}
